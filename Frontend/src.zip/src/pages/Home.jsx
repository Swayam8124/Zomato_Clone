// // import React, { useState } from "react";
// // import { FaSearch } from "react-icons/fa"; // Import search icon
// // import { motion } from "framer-motion"; // For smooth animations

// // const foodItems = [
// //   { id: 1, name: "Burger", image: "/images/burger.jpg" },
// //   { id: 2, name: "Pizza", image: "/images/pizza.jpg" },
// //   { id: 3, name: "Pasta", image: "/images/pasta.jpg" },
// //   { id: 4, name: "French Fries", image: "/images/fries.jpg" },
// //   { id: 5, name: "Biryani", image: "/images/biryani.jpg" },
// //   { id: 6, name: "Sushi", image: "/images/sushi.jpg" },
// //   { id: 7, name: "Tacos", image: "/images/tacos.jpg" },
// // ];

// // const Home = () => {
// //   const [searchTerm, setSearchTerm] = useState("");

// //   // Filter food items based on search input
// //   const filteredFood = foodItems.filter((food) =>
// //     food.name.toLowerCase().includes(searchTerm.toLowerCase())
// //   );

// //   return (
// //     <div className="min-h-screen bg-gray-100 flex flex-col items-center py-10 px-4">
// //       {/* Heading */}
// //       <h1 className="text-5xl font-extrabold text-red-500 mb-6">Find Your Favorite Food</h1>

// //       {/* Search Bar Container */}
// //       <div className="relative w-full max-w-lg mb-8">
// //         <input
// //           type="text"
// //           placeholder="Search for delicious food..."
// //           className="w-full p-4 pl-12 border rounded-full shadow-md focus:ring-2 focus:ring-red-400 outline-none text-lg transition-all"
// //           value={searchTerm}
// //           onChange={(e) => setSearchTerm(e.target.value)}
// //         />
// //         <FaSearch className="absolute left-4 top-4 text-gray-500 text-xl" />
// //       </div>

// //       {/* Food Item Grid */}
// //       <motion.div
// //         className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-4xl"
// //         initial={{ opacity: 0 }}
// //         animate={{ opacity: 1 }}
// //         transition={{ duration: 0.5 }}
// //       >
// //         {filteredFood.length > 0 ? (
// //           filteredFood.map((food) => (
// //             <motion.div
// //               key={food.id}
// //               className="bg-white rounded-xl shadow-lg overflow-hidden transform transition hover:scale-105"
// //               whileHover={{ scale: 1.05 }}
// //             >
// //               <img src={food.image} alt={food.name} className="w-full h-40 object-cover" />
// //               <div className="p-4 text-center">
// //                 <h2 className="text-lg font-semibold">{food.name}</h2>
// //               </div>
// //             </motion.div>
// //           ))
// //         ) : (
// //           <p className="text-gray-500 text-lg text-center col-span-3">No food items found</p>
// //         )}
// //       </motion.div>
// //     </div>
// //   );
// // };

// // export default Home;

// import React, { useState } from "react";
// import { FaSearch } from "react-icons/fa"; // Import search icon
// import { motion } from "framer-motion"; // For smooth animations

// const foodItems = [
//   { id: 1, name: "Burger", image: "https://plus.unsplash.com/premium_photo-1684534125661-614f59f16f2e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YnVyZ2Vyc3xlbnwwfHwwfHx8MA%3D%3D" },
//   { id: 2, name: "Pizza", image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" },
//   { id: 3, name: "Pasta", image: "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?q=80&w=2080&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" },
//   { id: 4, name: "Biryani", image: "https://media.istockphoto.com/id/1345624336/photo/chicken-biriyani.jpg?s=2048x2048&w=is&k=20&c=uU0uuti6KOvpQhXuu6VMpgi021o1vZXfOhpMrJXSn1o=" },
// ];

// const Home = () => {
//   const [searchTerm, setSearchTerm] = useState("");

//   // Filter food items based on search input
//   const filteredFood = foodItems.filter((food) =>
//     food.name.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   return (
//     <div className="min-h-screen bg-gray-50 flex flex-col items-center py-10 px-4">
//       {/* Heading */}
//       <motion.h1 
//         className="text-5xl font-extrabold text-red-500 mb-6"
//         initial={{ y: -50, opacity: 0 }}
//         animate={{ y: 0, opacity: 1 }}
//         transition={{ duration: 0.5 }}
//       >
//         Find Your Favorite Food 🍔🍕
//       </motion.h1>

//       {/* Search Bar Container */}
//       <div className="relative w-full max-w-lg mb-8">
//         <input
//           type="text"
//           placeholder="Search for delicious food..."
//           className="w-full p-4 pl-12 border border-gray-300 rounded-full shadow-md focus:ring-2 focus:ring-red-400 outline-none text-lg transition-all"
//           value={searchTerm}
//           onChange={(e) => setSearchTerm(e.target.value)}
//         />
//         <FaSearch className="absolute left-4 top-4 text-gray-500 text-xl" />
//       </div>

//       {/* Food Item Grid */}
//       <motion.div
//         className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-4xl"
//         initial={{ opacity: 0 }}
//         animate={{ opacity: 1 }}
//         transition={{ duration: 0.5 }}
//       >
//         {filteredFood.length > 0 ? (
//           filteredFood.map((food) => (
//             <motion.div
//               key={food.id}
//               className="bg-white rounded-xl shadow-lg overflow-hidden transform transition hover:scale-105"
//               whileHover={{ scale: 1.05 }}
//             >
//               <img src={food.image} alt={food.name} className="w-full h-40 object-cover" />
//               <div className="p-4 text-center">
//                 <h2 className="text-lg font-semibold">{food.name}</h2>
//               </div>
//             </motion.div>
//           ))
//         ) : (
//           <p className="text-gray-500 text-lg text-center col-span-3">No food items found</p>
//         )}
//       </motion.div>
//     </div>
//   );
// };

// export default Home;

import React, { useState } from "react";
import { FaSearch, FaShoppingCart } from "react-icons/fa"; // Import icons
import { motion } from "framer-motion"; // For animations

const foodItems = [
  { id: 1, name: "Burger", price: 5.99, image: "https://plus.unsplash.com/premium_photo-1684534125661-614f59f16f2e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8YnVyZ2Vyc3xlbnwwfHwwfHx8MA%3D%3D" },
  { id: 2, name: "Pizza", price: 8.99, image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" },
  { id: 3, name: "Pasta", price: 7.49, image: "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?q=80&w=2080&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" },
  { id: 4, name: "Biryani", price: 9.99, image: "https://media.istockphoto.com/id/1345624336/photo/chicken-biriyani.jpg?s=2048x2048&w=is&k=20&c=uU0uuti6KOvpQhXuu6VMpgi021o1vZXfOhpMrJXSn1o=" },
];

const Home = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [cart, setCart] = useState([]); // State to store cart items

  // Filter food items based on search input
  const filteredFood = foodItems.filter((food) =>
    food.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Add to Cart Function
  const addToCart = (food) => {
    let cart = JSON.parse(localStorage.getItem("cart")) || []; // Get existing cart
    cart.push(food); // Add new item
    localStorage.setItem("cart", JSON.stringify(cart)); // Save back to localStorage
    alert(`${food.name} added to cart!`);
  };
  

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center py-10 px-4">
      {/* Heading */}
      <motion.h1 
        className="text-5xl font-extrabold text-red-500 mb-6"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        Find Your Favorite Food 🍔🍕
      </motion.h1>

      {/* Search Bar */}
      <div className="relative w-full max-w-lg mb-8">
        <input
          type="text"
          placeholder="Search for delicious food..."
          className="w-full p-4 pl-12 border border-gray-300 rounded-full shadow-md focus:ring-2 focus:ring-red-400 outline-none text-lg transition-all"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <FaSearch className="absolute left-4 top-4 text-gray-500 text-xl" />
      </div>

      {/* Food Item Grid */}
      <motion.div
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-4xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {filteredFood.length > 0 ? (
          filteredFood.map((food) => (
            <motion.div
              key={food.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden transform transition hover:scale-105"
              whileHover={{ scale: 1.05 }}
            >
              <img src={food.image} alt={food.name} className="w-full h-40 object-cover" />
              <div className="p-4 text-center">
                <h2 className="text-lg font-semibold">{food.name}</h2>
                <p className="text-gray-600 text-sm mb-2">${food.price.toFixed(2)}</p>

                {/* Add to Cart Button */}
                <button
                  className="bg-red-500 text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-red-600 transition duration-300 flex items-center justify-center gap-2"
                  onClick={() => addToCart(food)}
                >
                  <FaShoppingCart /> Add to Cart
                </button>
              </div>
            </motion.div>
          ))
        ) : (
          <p className="text-gray-500 text-lg text-center col-span-3">No food items found</p>
        )}
      </motion.div>
    </div>
  );
};

export default Home;
